<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    use HasFactory;
    protected $fillable = [
        'address',
        'create_date',
        'due_date',
        'invoice',
        'note',
        'lrno',
        'status',
        'sub_total',
        'discount',
        'balance',
        'customer_id',
        'cgst',
        'sgst',
        'igst',
        'discount_type',
        'pfcouriercharge',
        'courier_charge',
        'transport',
        'orderno',
    ];

    public function items()
    {
        return $this->hasMany(InvoiceItem::class);
    }
    public function customer()
    {
        return $this->belongsTo(StakeHolder::class, 'customer_id', 'id');
    }
}
